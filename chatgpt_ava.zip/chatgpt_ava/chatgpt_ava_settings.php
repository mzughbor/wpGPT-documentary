<?php
// This file is intentionally left blank. There is no need for any PHP code here.
// The plugin uses the "chatgpt_ava_settings_page" function in the main plugin file to display the settings page content.
